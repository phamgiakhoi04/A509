package com.A509.Controller;

import com.A509.Service.ForgotPasswordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class ForgotPasswordController {

    @Autowired
    private ForgotPasswordService forgotPasswordService;

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> body) {
        try {
            String email = body.get("email");
            if (email == null || email.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("Vui lòng nhập email!");
            }
            email = email.trim();

            String response = forgotPasswordService.forgotPassword(email);
            return ResponseEntity.ok(response);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(503).body(e.getMessage());
        } catch (MailException e) {
            // Do not expose JavaMail's low-level message (for example
            // "Could not parse mail") to the browser.  It almost always
            // means the Gmail sender/App Password is missing or invalid.
            return ResponseEntity.status(503).body("Không thể gửi email lúc này. Hãy kiểm tra MAIL_USERNAME và MAIL_PASSWORD (Gmail App Password) rồi khởi động lại backend.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> body) {
        try {
            String token = body.get("token");
            String newPassword = body.get("newPassword");

            if (token == null || newPassword == null) {
                return ResponseEntity.badRequest().body("Thiếu thông tin token hoặc mật khẩu mới!");
            }

            forgotPasswordService.resetPassword(token, newPassword);
            return ResponseEntity.ok("Đổi mật khẩu thành công! Hãy đăng nhập lại.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
